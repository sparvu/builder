return {
  _NAME      = "ZipWriter";
  _VERSION   = "0.1.6-dev";
  _COPYRIGHT = "Copyright (C) 2013-2016 Alexey Melnichuk";
  _LICENSE   = "MIT";
}