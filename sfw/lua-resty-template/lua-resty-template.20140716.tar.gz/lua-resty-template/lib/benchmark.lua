local benchmark = require "resty.template.microbenchmark"
benchmark.run()
